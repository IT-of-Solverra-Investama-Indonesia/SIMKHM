<?php 

$tenaga=$koneksi->query("SELECT * FROM admin;"); 

?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
  </head>
  <body>
    <!-- <h3>Daftar User</h3> -->
  	<!-- <div class="card shadow-lg w-100 p-3">

  		<form method="post">
  			<div class="mb-3">
			  <input type="text" class="form-control" name="nama" placeholder="Nama Lengkap">
			</div>
			<div class="mb-3">
			  <textarea class="form-control" placeholder="Alamat" name="alamat"></textarea>
			</div>
			<div class="mb-3">
			  <select class="form-select" name="jabatan" aria-label="Default select example">
				  <option hidden>Jabatan</option>
				  <option value="dokter">Dokter</option>
				  <option value="perawat">Perawat</option>
				  <option value="tenaga medis">Tenaga Medis</option>
				  <option value="dll">DLL</option>
				</select>
			</div>
			<div class="mb-3">
			  <input type="number" class="form-control" name="nip" placeholder="NIP">
			</div>
			<center>
				<button class="btn btn-primary" name="tambah">Tambahkan</button>
			</center>
  		</form>
  	</div>

  	<?php 

  	if (isset ($_POST['tambah'])) {
  		$nama = $_POST['nama'];
  		$alamat= $_POST['alamat'];
  		$jabatan= $_POST['jabatan'];
  		$NIP = $_POST['nip'];

  		$koneksi->query("INSERT INTO tenaga_medis (nama_tenaga, alamat_tenaga, jabatan, NIP, level) VALUES ('$nama', '$alamat', '$jabatan', '$NIP', '$_POST[level]')");
  		echo "
  			<script>
  				document.location.href='index.php?halaman=tenagamedis';	
  			</script>
  		";

  	}

  	 ?> -->
	<div class="card p-3 shadow">
		<h4>Daftar User</h4>
		<div class="w-100 table-responsive">
			<table class="table table-striped w-100">
			<thead>
			  <tr>
				<th scope="col">Nama</th>
				<th scope="col">Username</th>
				<th scope="col">Password</th>
				<th scope="col">Level</th>
				<th scope="col">NIK</th>
				<th>Action</th>
			  </tr>
			</thead>
			<tbody>
				<?php foreach ($tenaga as $data): ?>
				  <tr>
					<th scope="row"><?php echo $data["namalengkap"]; ?></th>
					<td><?php echo $data["username"]; ?></td>
					<td><?php echo $data["password"]; ?></td>
					<td><?php echo $data["level"]; ?></td>
					<td><?php echo $data["nik"]; ?></td>
					<td>
						<button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#edit<?php echo $data["idadmin"]; ?>">
						Update
					  </button>
					  <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#del<?php echo $data["idadmin"]; ?>">
						Hapus
					  </button>
					</td>
				  </tr>
				<?php endforeach; ?>
			</tbody>
		  </table>
		</div>
	</div>

  	<?php foreach ($tenaga as $data): ?>
  		<div class="modal fade" id="edit<?php echo $data["idadmin"]; ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
		  <div class="modal-dialog">
		    <div class="modal-content">
		      <div class="modal-header">
		        <h1 class="modal-title fs-5" id="staticBackdropLabel">Edit <?php echo $data["namalengkap"]; ?></h1>
		        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
		      </div>
		      <div class="modal-body">
		        <form method="post">
		        	<div class="mb-3">
		        		<input type="number" name="id" value="<?php echo $data["idadmin"]; ?>" hidden disable>
					  <input type="text" class="form-control" name="namalengkap" placeholder="Nama Lengkap" value="<?php echo $data["namalengkap"]; ?>">
					</div>
					<div class="mb-3">
						<input type="text" class="form-control" name="username" placeholder="Username" value="<?php echo $data["username"]; ?>">
					</div>
					
					<div class="mb-3">
						<input type="password" class="form-control" name="password" placeholder="Password" value="<?php echo $data["password"]; ?>">
					</div>
					<div class="mb-3">
						<input type="text" class="form-control" name="NIK" placeholder="NIK" value="<?php echo $data["NIK"]; ?>">
					</div>
					
					<div class="mb-3">
                      <label for="">Level</label>
                      <select name="level" id="" class="form-control">
                        <option value="<?php echo $data["level"]; ?>" hidden><?php echo $data["level"]; ?></option>

							          <option value="perawat">perawat</option>

							          <option value="igd">igd</option>

							          <!-- <option value="apotik">apotik</option> -->

							          <option value="apoteker">apoteker</option>

							          <option value="daftar">daftar</option>

							          <option value="dokter">dokter</option>

							          <option value="kasir">kasir</option>

							          <option value="inap">inap</option>
									  
									  <option value="kosmetik">kosmetik</option>
							          <option value="sup">sup</option>
							          <option value="lab">lab</option>
                      </select>
                    </div>
					
			      <div class="modal-footer">
			        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
			        <button class="btn btn-primary" name="update">Update</button>
			      </div>
		        </form>
		      </div>
		    </div>
		  </div>
		</div>
  	<?php endforeach; ?>


  	<?php foreach ($tenaga as $data): ?>
  		<div class="modal fade" id="del<?php echo $data["idadmin"]; ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
		  <div class="modal-dialog">
		    <div class="modal-content">
		      <div class="modal-header">
		        <h1 class="modal-title fs-5" id="staticBackdropLabel">Hapus <?php echo $data["username"]; ?></h1>
		        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
		      </div>
		      <div class="modal-body">
		        Data yang dihapus tidak dapat dikembalikan, apakah anda yakin ingin menghapus data ini ?
		      </div>
		      <div class="modal-footer">
		        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
		        <!-- <button type="button" class="btn btn-danger">Hapus</button> -->
		        <!-- <a href='hapus_jurusan.php?hapus_id_jurusan=".$row['id_jurusan']>Hapus </a> -->
		        <a href="index.php?halaman=tenagamedis&id=<?php echo $data["idadmin"]; ?>" class="btn btn-danger">Hapus</a>
		      </div>
		    </div>
		  </div>
		</div>
  	<?php endforeach ;?>

  	<?php 
  		if (isset($_POST['update'])) {
			$username=htmlspecialchars($_POST["username"]);
			$namalengkap=htmlspecialchars($_POST["namalengkap"]);
			$password=($_POST["password"]);
			$level=($_POST["level"]);
	  		$id = $_POST['id'];
			// if($_POST['NIK']==''){
			// 	$koneksi->query("UPDATE admin SET username='$username', namalengkap='$namalengkap', password='$password', level='$level' WHERE idadmin='$id'");
			// }else{
			// 	$getToken = curl_init();
			// 	curl_setopt_array($getToken, array(
			// 	CURLOPT_URL => 'https://api-satusehat.kemkes.go.id/oauth2/v1/accesstoken?grant_type=client_credentials',
			// 	CURLOPT_RETURNTRANSFER => true,
			// 	CURLOPT_ENCODING => '',
			// 	CURLOPT_MAXREDIRS => 10,
			// 	CURLOPT_TIMEOUT => 0,
			// 	CURLOPT_FOLLOWLOCATION => true,
			// 	CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			// 	CURLOPT_CUSTOMREQUEST => 'POST',
			// 	CURLOPT_POSTFIELDS => 'client_id=pnZFT0j4Hs1FKIqQKeRspG1ncJwauPVKNnrT2OeiuPpP2E3l&client_secret=FNTJCctvzsWjmjb7VHGbdzLT1xLG9FcV8bAWql27GKJ8o9S5iXxHvOQYpi85qzzv',
			// 	CURLOPT_HTTPHEADER => array(
			// 		'Content-Type: application/x-www-form-urlencoded',
			// 		'Authorization: Bearer WVqDq4p8tYLyaNtYtCDytoaJLNJj'
			// 	),
			// 	));
				
			// 	$responseToken = curl_exec($getToken);
				
			// 	curl_close($getToken);
			// 	// echo $responseToken;
			// 	$pecahToken = json_decode($responseToken, true);
			// 	$token = $pecahToken['access_token'];

			// 	$curl = curl_init();
			// 	curl_setopt_array($curl, array(
			// 	  CURLOPT_URL => 'https://api-satusehat.kemkes.go.id/fhir-r4/v1/Practitioner?identifier=https%3A%2F%2Ffhir.kemkes.go.id%2Fid%2Fnik%7C'.$_POST['NIK'],
			// 	  CURLOPT_RETURNTRANSFER => true,
			// 	  CURLOPT_ENCODING => '',
			// 	  CURLOPT_MAXREDIRS => 10,
			// 	  CURLOPT_TIMEOUT => 0,
			// 	  CURLOPT_FOLLOWLOCATION => true,
			// 	  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			// 	  CURLOPT_CUSTOMREQUEST => 'GET',
			// 	  CURLOPT_HTTPHEADER => array(
			// 		'Content-Type: application/json',
			// 		'Authorization: Bearer '.$token
			// 	  ),
			// 	));
				
			// 	$response = curl_exec($curl);
			// 	curl_close($curl);
			// 	$getIHS = json_decode($response, true);
				
			// 	$IHS = $getIHS['entry'][0]['resource']['id'];
			
				$koneksi->query("UPDATE admin SET username='$username', NIK='$_POST[NIK]', namalengkap='$namalengkap', password='$password', level='$level' WHERE idadmin='$id'");
			
	  		echo "
	  			<script>
	  				document.location.href='index.php?halaman=tenagamedis';	
	  			</script>
	  		";
	  	}

	  	if (isset($_GET['id'])){
	  		$idd=$_GET['id'];
	  		$koneksi->query("DELETE FROM admin WHERE idadmin='$idd'");
	  		echo "
	  			<script>
	  				document.location.href='index.php?halaman=tenagamedis';	
	  			</script>
	  		";
	  	}
  	 ?>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.7/dist/umd/popper.min.js" integrity="sha384-zYPOMqeu1DAVkHiLqWBUTcbYfZ8osu1Nd6Z89ify25QV9guujx43ITvfi12/QExE" crossorigin="anonymous"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.min.js" integrity="sha384-Y4oOpwW3duJdCWv5ly8SCFYWqFDsfob/3GkgExXKV4idmbt98QcxXYs9UoXAB7BZ" crossorigin="anonymous"></script>
  </body>
</html>

